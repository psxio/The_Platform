# Portable Generators

This folder contains all the generator functionality from the PSX app that can be added to another Next.js application.

## What's Included

### 1. NFT Metadata Generator
- **Component**: `components/nft-metadata-generator.tsx`
- **API Route**: `app/nft/metadata/[id]/route.ts`
- **Script**: `scripts/generate-nft-metadata.ts`
- Generates OpenSea-compatible JSON metadata for 8,888 NFT collection
- Traits: Burned, First Lit, Days Lit, Fires Started

### 2. Shadow PFP Generator
- **Component**: `components/shadow-pfp-generator.tsx`
- **Libraries**: `lib/shadow-pfp-renderer.ts`, `lib/shadow-bulk-renderer.ts`
- Generates mystery/shadow silhouette versions of PFPs
- Bulk generation with ZIP download

### 3. Bulk PFP Generator
- **Component**: `components/bulk-pfp-generator.tsx`
- **Libraries**: `lib/bulk-pfp-generator.ts`, `lib/bulk-renderer.ts`
- Generates unique PFP combinations in bulk
- Includes metadata generation

### 4. Empty Metadata Generator
- **Library**: `lib/empty-metadata-generator.ts`
- Generates empty/placeholder metadata JSONs

## Required Dependencies

Add these to your `package.json`:

```bash
npm install jszip lucide-react
```

Also requires (likely already in your Next.js project):
- react
- @radix-ui/react-progress (or your UI library)
- tailwindcss

## Required UI Components

These generators use shadcn/ui components. Make sure you have:
- `components/ui/button.tsx`
- `components/ui/card.tsx`
- `components/ui/input.tsx`
- `components/ui/label.tsx`
- `components/ui/progress.tsx`

## Setup Instructions

1. **Copy files to your project:**
   ```
   components/nft-metadata-generator.tsx → your-app/components/
   components/shadow-pfp-generator.tsx → your-app/components/
   components/bulk-pfp-generator.tsx → your-app/components/
   lib/*.ts → your-app/lib/
   app/nft/metadata/[id]/route.ts → your-app/app/nft/metadata/[id]/route.ts
   scripts/generate-nft-metadata.ts → your-app/scripts/
   ```

2. **Install dependencies:**
   ```bash
   npm install jszip
   ```

3. **Import and use in your page:**
   ```tsx
   import { NFTMetadataGenerator } from "@/components/nft-metadata-generator"
   import { ShadowPFPGenerator } from "@/components/shadow-pfp-generator"
   import { BulkPFPGenerator } from "@/components/bulk-pfp-generator"

   export default function GeneratorsPage() {
     return (
       <div className="space-y-8 p-8">
         <NFTMetadataGenerator />
         <ShadowPFPGenerator />
         <BulkPFPGenerator />
       </div>
     )
   }
   ```

4. **Run the bulk script (optional):**
   ```bash
   npx tsx scripts/generate-nft-metadata.ts
   ```

## File Structure

```
portable-generators/
├── components/
│   ├── nft-metadata-generator.tsx    # NFT metadata UI
│   ├── shadow-pfp-generator.tsx      # Shadow PFP generator UI
│   └── bulk-pfp-generator.tsx        # Bulk PFP generator UI
├── lib/
│   ├── bulk-pfp-generator.ts         # Bulk generation logic
│   ├── bulk-renderer.ts              # Bulk rendering
│   ├── empty-metadata-generator.ts   # Empty metadata
│   ├── shadow-bulk-renderer.ts       # Shadow bulk rendering
│   ├── shadow-pfp-renderer.ts        # Shadow PFP rendering
│   ├── pfp-traits.ts                 # Trait definitions
│   └── utils.ts                      # Utility functions
├── scripts/
│   └── generate-nft-metadata.ts      # CLI script for bulk generation
├── app/
│   └── nft/
│       └── metadata/
│           └── [id]/
│               └── route.ts          # API endpoint for metadata
└── README.md
```

## NFT Metadata Format

Each NFT metadata file includes:
```json
{
  "name": "Matchstick Countdown #1",
  "description": "A unique collection of 8,888 NFTs...",
  "image": "https://matchstick-countdown-ryankagygamesto.replit.app",
  "animation_url": "https://matchstick-countdown-ryankagygamesto.replit.app",
  "external_url": "https://matchstick-countdown-ryankagygamesto.replit.app",
  "attributes": [
    { "trait_type": "Burned", "value": "False" },
    { "trait_type": "First Lit", "value": -1 },
    { "trait_type": "Days Lit", "value": 0 },
    { "trait_type": "Fires Started", "value": 0 }
  ]
}
```

## Customization

To customize the NFT metadata (name, description, media URL, traits), edit:
- `components/nft-metadata-generator.tsx` - UI component
- `app/nft/metadata/[id]/route.ts` - API endpoint
- `scripts/generate-nft-metadata.ts` - Bulk generation script
